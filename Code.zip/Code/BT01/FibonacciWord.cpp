#include <iostream>
#include <iomanip>

using namespace std;

int main ()
{
    freopen("FibonacciWord.cpp" , "r" , stdin);
    string f0 = "a";
    string f1 = "b";
    cout << f0 << ' ' << f1 << ' ';
    for (int i = 2; i <= 10; i++)
    {
        string fn = f1 + f0;
        f0 = f1;
        f1 = fn;
        cout << fn << ' ';
    }
    freopen ("FibonacciWord.cpp" , "w" , stdout);
    return 0;
}
