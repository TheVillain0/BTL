#include<bits/stdc++.h>
using namespace std;

void BasicStatistic (int a[], int n )
{
    for (int i=0 ; i<n ;i++) {
        cin >> a[n];
    }
}

int Max (int a[] , int n)
{
    int max=a[0];
    for (int i=1 ; i<n ; i++) {
        if (a[i]>max) {
            max = a[i];
        }
    }
    return max;
}


int main ()
{
    int a[1000];
    int n; cin >> n;
    BasicStatistic(a,n);
    cout << Max(a,n);
    return 0;
}
