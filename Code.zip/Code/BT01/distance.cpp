#include<bits/stdc++.h>

using namespace std;

int main ()
{
    freopen ("distance.cpp" , "r" , stdin);
    int x,y ;
    cin >> x >> y ;
    cout << sqrt(x*x + y*y) ;
    freopen ("distance.cpp" , "w" , stdout);
    return 0;
}
